## /small_img

This folder contains the *unzipped* images of `small_img.zip` from the problem statement.
