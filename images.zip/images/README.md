## /images

This folder contains the *unzipped* images of `images.zip` from the problem statement.
